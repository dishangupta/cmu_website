UNCOMPRESSED DIRECTORY STRUCTURE - The root of the uncompressed zip file contains four folders with the last three containing 
fifty four sub-folders for each. Each sub-folder further contains four files. 

FOUR FOLDERS:
	Annotations - All the annotations for NeSS and its baselines.
	NeSS_18_75 - Results for the 54 query phrases using 18.75% of the English Gigaword 5th edition.
	NeSS_37_50 - Results for the 54 query phrases using 37.50% of the English Gigaword 5th edition.
	NeSS_71_88 - Results for the 54 query phrases using 71.88% of the English Gigaword 5th edition.

LAST THREE FOLDERS:
	FIFTY FOUR SUBFOLDERS - One for each query phrase.

		FOUR FILES:
		query phrase.result.html - Shared Context and KL-Divergence results for the query phrase. Can be obtained by clicking the tabs saying "Shared Context" and "KL-Divergence", respectively.
		query_phrase.left - Left contexts of the query phrase.
		query_phrase.lr - Combined left and right contexts (cradles) of the query phrase.
		query_phrase.right - Right contexts of the query phrase.

ANNOTATIONS FOLDER:
	H&S_Annotator{i} - Annotations for Huang and Socher's single-prototype word embeddings for the 15 single word query phrases. (i = {1, 2, 3})
	Mavuno_37_50 - Annotations for Mavuno for the 54 query phrases using 37.50% of the English Gigaword 5th edition.
	NeSS_18_75_SFG - Annotations for NeSS's SFG function for the 54 query phrases using 18.75% of the English Gigaword 5th edition.
	NeSS_37_50_Annotator{i} - Annotations for NeSS's SFG and KL functions for the 54 query phrases using 37.50% of the English Gigaword 5th edition. (i = {1, .., 6})
	NeSS_71_88_SFG - Annotations for NeSS's SFG function for the 54 query phrases using 71.88% of the English Gigaword 5th edition.
	PPDB - Annotations for PPDB for the 54 query phrases.
	Roget'sThesaurus_Annotator{i} - Annotations for Roget's Thesaurus for the 54 query phrases. (i = {1, 2, 3})
	

